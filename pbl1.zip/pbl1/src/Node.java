public class Node {
    int x, y;
    Node proximo;

    Node(int x, int y) {
        this.x = x;
        this.y = y;
        this.proximo = null;
    }
}